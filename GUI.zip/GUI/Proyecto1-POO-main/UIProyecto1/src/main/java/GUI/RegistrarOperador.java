package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 

public class RegistrarOperador extends JFrame implements ActionListener {
 
    Container container = getContentPane();
    
    JTextField TextFieldNombreCompleto = new JTextField();
    JTextField TextFieldCorreo = new JTextField();
    
    JLabel TextoNombreCompleto = new JLabel("Nombre Completo");
    JLabel TextoCorreoElectronico = new JLabel("Correo Electrónico");
    
    JButton botonAtras = new JButton("Atrás");
    JButton botonAgregarOperador = new JButton("Agregar");
 
 
 
    RegistrarOperador() {
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();
        addActionEvent();
 
    }
 
    public void setLayoutManager() {
        container.setLayout(null);
    }
 
    public void setLocationAndSize() {
        TextoNombreCompleto.setBounds(70, 100, 150, 30);
        TextoCorreoElectronico.setBounds(70, 140, 150, 30);
        
        TextFieldNombreCompleto.setBounds(200, 100, 150, 30);
        TextFieldCorreo.setBounds(200, 140, 150, 30);
        
       botonAgregarOperador.setBounds((200-150/2), 300, 150, 30);
        botonAtras.setBounds(200,30, 150, 30);
 
 
    }
 
    public void addComponentsToContainer() {
        container.add(botonAgregarOperador);
        container.add(TextoNombreCompleto);
        container.add(TextoCorreoElectronico);
       
        container.add(TextFieldNombreCompleto);
        container.add(TextFieldCorreo);
 
        container.add(botonAtras);
    }
 
    public void addActionEvent() {

        botonAtras.addActionListener(this);
        botonAgregarOperador.addActionListener(this);
    }
 
 
    @Override
    public void actionPerformed(ActionEvent e) {
        //Coding Part of LOGIN button
        if (e.getSource()==botonAtras){
            TextFieldNombreCompleto.setText("");
            TextFieldCorreo.setText("");
            
            Login.VentanaMenuPrincipal(true);
            Login.VentanaRegistrarOperador(false);
          
        }
        if (e.getSource()==botonAgregarOperador){
            String NombreTemporal;
            String correoTemporal;
            NombreTemporal = TextFieldNombreCompleto.getText();
            correoTemporal = TextFieldCorreo.getText();
            
            if (NombreTemporal.equals("") || correoTemporal.equals("")) {
            JOptionPane.showMessageDialog(this, "Correo ingresado inválido");    
            
            } else {
            JOptionPane.showMessageDialog(this, "Se ha agregado un nuevo usuario para Soporte al Cliente!");
            TextFieldNombreCompleto.setText("");
            TextFieldCorreo.setText("");
            Login.VentanaMenuPrincipal(true);
            Login.VentanaRegistrarOperador(false);    
                
            }

        }
        
       //Coding Part of showPassword JCheckBox
    }
 
}